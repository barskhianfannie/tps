import Server from "next/server";

/**
 * API route that returns the USD value of token prices keyed by token symbol.
 */
export const GET = () => {
  return Server.NextResponse.json({
    BTC: "27,398.70",
    ETH: "1651.59",
    LTC: "65.94",
  });
};
