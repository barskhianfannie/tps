"use client";

import { useEffect, useState } from "react";

/**
 * Renders a crypto portfolio
 */
export default function Home() {
  const [price, setPrice] = useState(null);

  const quantities = {
    BTC: 4.56,
    ETH: 0.23,
    LTC: 3.18,
  };

  useEffect(() => {
    // Fetch data from the API route: "/api/price"
  }, []);

  return (
    <main>
      <h1>Crypto portfolio</h1>

      {/* Display portfolio data here */}
    </main>
  );
}
