# Crypto Portfolio

Your task is to create a table that displays your crypto tokens balances, USD Prices, and the total portfolios net value.

It should have 3 columns:

1. Token Name
2. Quantity
3. USD Price

It should also have an additional row at the end that displays the total price value of the portfolio.

## Getting Started

First, run the development server:

```bash
npm run dev
# or
yarn dev
# or
pnpm dev
# or
bun dev
```

Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

You can start editing the page by modifying `app/page.tsx`. The page auto-updates as you edit the file.
